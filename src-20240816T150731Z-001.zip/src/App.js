import './App.css';
import LandingPage from './LandingPage';

function App() {
  return (
      <LandingPage/>
  );
}

export default App;
